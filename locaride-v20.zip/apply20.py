# v20: pubblica le salite nuove dell'Appennino (6 regioni), senza doppioni tra regioni.
import hashlib, os, shutil, sys
EXPECT = {"scripts/promote_discover.mjs": "9c1d4aea6f1c1756516d9bca904c1e6aa473fc6f06a0d5d7ab9d49bb42ab36a9"}
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
bad = [f for f, h in EXPECT.items() if sha(f) != h and sha(f) != sha("v20/" + f)]
if bad: print("STOP: file cambiati rispetto alla versione attesa, non tocco nulla:", ", ".join(bad)); sys.exit(1)
for root, _, files in os.walk("v20"):
    for fn in files:
        src = os.path.join(root, fn); dst = os.path.relpath(src, "v20")
        shutil.copyfile(src, dst); print("  copiato", dst)
shutil.rmtree("v20"); print("FATTO")
