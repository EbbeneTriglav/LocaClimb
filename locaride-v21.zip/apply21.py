# v21: titoli della scheda tornati, taglio del fondovalle nelle salite trovate, nuova ricerca su tutte le regioni.
# Include anche la v20 (se non l'hai gia' applicata): promote senza doppioni tra regioni + file di revisione.
import hashlib, os, re, shutil, sys, time
EXPECT = {
 "js/discoverview.js": "f231ebc37f02354a10a4bf62bc4fc0ac5cc5b1a36d5e3fd9c4cfba74d421dbe0",
 "js/signage.js": "12987858b7868cb4df0e5428190f7c7fd75a1f1c7f03bbdf59307b7da7b2ca64",
 "test/signage.test.mjs": "6b02f9e73e351ddb91f74a7d8afce19691295c0a6cd15f465fd87d0f79dd0074",
 "scripts/lib/discover.mjs": "712e6a99e9c97fec6fdf8cb54251aa24bd3ed6878af235fb4c6de216bd8de2b6",
 "scripts/build_osm_passes.mjs": "b61e6f8f052a4f79efb91df8a44dd1be6523b56d132f8fc5e67aa3074b347226",
 "test/discover.test.mjs": "19232a4dd63d08ffbe408359645fe16884c5105b04e874b26e39fc92642d139b",
 ".github/workflows/osm-discover.yml": "874e96b82c396ad377c9500d1582245f720b3d759cd892499848c5062b6f266a",
 "scripts/promote_discover.mjs": "7cb1a7c804f608fd2869b8773785b7696a95d85c28e7581c5f190b3864c037be"
}
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
bad = [f for f, h in EXPECT.items() if sha(f) != h and sha(f) != sha("v21/" + f)]
if bad: print("STOP: file cambiati rispetto alla versione attesa, non tocco nulla:", ", ".join(bad)); sys.exit(1)
for root, _, files in os.walk("v21"):
    for fn in files:
        src = os.path.join(root, fn); dst = os.path.relpath(src, "v21")
        os.makedirs(os.path.dirname(dst) or ".", exist_ok=True); shutil.copyfile(src, dst); print("  copiato", dst)
p = "index.html"; s = open(p, encoding="utf-8").read()
for name in ["js/signage.js", "js/discoverview.js"]:
    s, n = re.subn(re.escape(name) + r'(\?v=\d+)?"', name + '?v=%d"' % int(time.time()), s)
    print("  index.html: " + name + (" aggiornato" if n else " NON trovato"))
open(p, "w", encoding="utf-8").write(s)
shutil.rmtree("v21"); print("FATTO")
