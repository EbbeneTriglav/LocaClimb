# v18: ricerca salite automatica su tutte le regioni, acqua e ristori dai nostri dati, nuova scheda salita.
import hashlib, os, re, shutil, sys, time
EXPECT = {".github/workflows/osm-discover.yml": "6d1c310450f5eeb6ee11c9f23bc160e4339eb1b2a9badb82a2cdef6c29036f2d", "scripts/build_osm_passes.mjs": "57035975b4ba60f744fa12a51d67d8a09d2308c20af244b91cb8fa2180d720e7"}
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
bad = [f for f, h in EXPECT.items() if sha(f) != h and sha(f) != sha("v18/" + f)]
if bad: print("STOP: file cambiati rispetto alla versione attesa, non tocco nulla:", ", ".join(bad)); sys.exit(1)
for f in ["js/signage.js", "js/poilocal.js", "css/brand.css", "scripts/build_poi.mjs"]:
    if os.path.exists(f) and sha(f) != sha("v18/" + f): print("STOP: esiste gia' un " + f + " diverso, non lo sovrascrivo"); sys.exit(1)
for root, _, files in os.walk("v18"):
    for fn in files:
        src = os.path.join(root, fn); dst = os.path.relpath(src, "v18")
        os.makedirs(os.path.dirname(dst) or ".", exist_ok=True); shutil.copyfile(src, dst); print("  copiato", dst)
p = "index.html"; s = open(p, encoding="utf-8").read(); v = int(time.time())
if "css/brand.css" not in s:
    m = re.search(r'<link rel="stylesheet" href="css/ui\.css[^"]*">', s)
    if not m: print("STOP: link css/ui.css non trovato in index.html"); sys.exit(1)
    s = s[:m.end()] + '\n<link rel="preload" href="fonts/overpass-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>\n<link rel="stylesheet" href="css/brand.css?v=%d">' % v + s[m.end():]
if "js/signage.js" not in s:
    m = re.search(r'<script src="js/discoverview\.js[^"]*"></script>', s)
    if not m: print("STOP: riga discoverview.js non trovata in index.html"); sys.exit(1)
    s = s[:m.end()] + '\n<script src="js/poilocal.js?v=%d"></script>\n<script src="js/signage.js?v=%d"></script>' % (v, v) + s[m.end():]
open(p, "w", encoding="utf-8").write(s); print("  index.html: font, brand.css, poilocal.js, signage.js")
shutil.rmtree("v18"); print("FATTO")
