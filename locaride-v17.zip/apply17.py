# v17: ricerca salite estesa a 10 regioni. Copia i file SOLO se quelli nel repo sono la versione attesa.
import hashlib, os, shutil, sys
EXPECT = {
  "scripts/build_osm_passes.mjs": "832018295f426bc09bb0412ed0fe8769f60131a9762ce81bc825a138423b7d13",
  "scripts/lib/discover.mjs": "a9411bb731f15f36d394144e5978324b28f6c4dea62182fcbf8eab944149391f",
  "js/discoverview.js": "7e6b8399560aa15453bb1feb3daae9b0e109edb1c839bae3b32f85a8c082350a",
  "scripts/promote_discover.mjs": "4d400405366803c4106554b3cf57e679e08132cce39c87ecf32e582b2b42d198",
  "test/discover.test.mjs": "89bf170c4949e80f422eace5f95dc63bd8b0a566a9510a166b1c230fd33b63e7",
  ".github/workflows/osm-discover.yml": "a1ecac8f450a9ceafd039bec4f85b1e6292240f70694ef68b23e7758ab2c8144",
}
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
bad = [f for f, h in EXPECT.items() if sha(f) != h and sha(f) != sha("v17/" + f)]
if bad: print("STOP: file cambiati rispetto alla versione attesa, non tocco nulla:", ", ".join(bad)); sys.exit(1)
for f in EXPECT: shutil.copyfile("v17/" + f, f); print("  copiato", f)
shutil.rmtree("v17"); print("FATTO")
