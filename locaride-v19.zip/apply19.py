# v19: mappa a punti con filtri per categoria, testata pulita sul telefono.
import hashlib, re, shutil, sys, time
EXPECT = {"js/mapux.js": "176d88bb3f667fe78541ee97ac9766d1918859015da1ca40d52e25fdf3f13648", "js/signage.js": "eb84f44ecbd9037db1650997b15df32a2d44c8e1cfc99b6bf8afd42ec7231e53", "js/panelplus.js": "552c154dbce1ae54b2eb9abf89d3a5bc5e53bd2cc51d24b402338d25ae81f54d", "css/brand.css": "f741ae6b2a52f9cb92a1e50010d926d0182527d28e8432096b1a5736748b91f1", "test/mapux.test.mjs": "a8ec123fd0e18714d1d34bbdbcd5cfb3ea3a9f9ead0ff8d8b61bd089021d6cb7"}
sha = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
bad = [f for f, h in EXPECT.items() if sha(f) != h and sha(f) != sha("v19/" + f)]
if bad: print("STOP: file cambiati rispetto alla versione attesa, non tocco nulla:", ", ".join(bad)); sys.exit(1)
for f in EXPECT: shutil.copyfile("v19/" + f, f); print("  copiato", f)
p = "index.html"; s = open(p, encoding="utf-8").read(); v = int(time.time())
for name in ["js/mapux.js", "js/signage.js", "js/panelplus.js", "css/brand.css"]:
    s, n = re.subn(re.escape(name) + r'(\?v=\d+)?"', name + '?v=%d"' % v, s)
    print("  index.html: " + name + (" aggiornato" if n else " NON trovato"))
open(p, "w", encoding="utf-8").write(s)
shutil.rmtree("v19"); print("FATTO")
